<script lang="ts">



</script>

<div class="flex justify-center h-screen items-center ">
    <a href="/app" class="bg-emerald-700 px-3 py-2 flex items-center justify-center max-w-16 rounded-lg text-white">App</a>
</div>