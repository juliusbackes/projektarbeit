import Root from "./input.svelte";

export {
	Root,
	//
	Root as Input,
};
