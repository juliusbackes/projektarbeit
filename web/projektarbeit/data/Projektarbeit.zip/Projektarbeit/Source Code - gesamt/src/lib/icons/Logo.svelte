<svg width="45" height="45" viewBox="0 0 280 280" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_2_2)">
    <rect x="4" width="272" height="272" rx="35" fill="#047857"/>
    </g>
    <g filter="url(#filter1_d_2_2)">
    <circle cx="140.5" cy="137.5" r="30.5" stroke="white" stroke-width="4" shape-rendering="crispEdges"/>
    </g>
    <g filter="url(#filter2_d_2_2)">
    <circle cx="215.5" cy="137.5" r="15.5" stroke="white" stroke-width="4"/>
    <line x1="173" y1="137.5" x2="198" y2="137.5" stroke="white" stroke-width="3"/>
    <line x1="232" y1="137.5" x2="257" y2="137.5" stroke="white" stroke-width="3"/>
    </g>
    <g filter="url(#filter3_d_2_2)">
    <circle cx="140.5" cy="212.5" r="15.5" transform="rotate(90 140.5 212.5)" stroke="white" stroke-width="4"/>
    <line x1="140.5" y1="170" x2="140.5" y2="195" stroke="white" stroke-width="3"/>
    <line x1="140.5" y1="229" x2="140.5" y2="254" stroke="white" stroke-width="3"/>
    </g>
    <g filter="url(#filter4_d_2_2)">
    <circle cx="65.5" cy="137.5" r="15.5" transform="rotate(180 65.5 137.5)" stroke="white" stroke-width="4"/>
    <line x1="108" y1="137.5" x2="83" y2="137.5" stroke="white" stroke-width="3"/>
    <line x1="49" y1="137.5" x2="24" y2="137.5" stroke="white" stroke-width="3"/>
    </g>
    <g filter="url(#filter5_d_2_2)">
    <circle cx="140.5" cy="62.5" r="15.5" transform="rotate(-90 140.5 62.5)" stroke="white" stroke-width="4"/>
    <line x1="140.5" y1="105" x2="140.5" y2="80" stroke="white" stroke-width="3"/>
    <line x1="140.5" y1="46" x2="140.5" y2="21" stroke="white" stroke-width="3"/>
    </g>
    <g filter="url(#filter6_d_2_2)">
    <circle cx="208.104" cy="205.104" r="16.5" transform="rotate(45 208.104 205.104)" stroke="white" stroke-width="2"/>
    <line x1="160.707" y1="158.293" x2="196.062" y2="193.648" stroke="white" stroke-width="2"/>
    </g>
    <g filter="url(#filter7_d_2_2)">
    <circle cx="212.478" cy="70.7487" r="16.5" transform="rotate(-45 212.478 70.7487)" stroke="white" stroke-width="2"/>
    <line x1="165.667" y1="118.146" x2="201.023" y2="82.7904" stroke="white" stroke-width="2"/>
    </g>
    <g filter="url(#filter8_d_2_2)">
    <circle cx="69.7487" cy="68.7487" r="16.5" transform="rotate(-135 69.7487 68.7487)" stroke="white" stroke-width="2"/>
    <line x1="117.146" y1="115.56" x2="81.7904" y2="80.2046" stroke="white" stroke-width="2"/>
    </g>
    <g filter="url(#filter9_d_2_2)">
    <circle cx="69.7487" cy="205.478" r="16.5" transform="rotate(135 69.7487 205.478)" stroke="white" stroke-width="2"/>
    <line x1="116.56" y1="158.081" x2="81.2046" y2="193.437" stroke="white" stroke-width="2"/>
    </g>
    <defs>
    <filter id="filter0_d_2_2" x="0" y="0" width="280" height="280" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dy="4"/>
    <feGaussianBlur stdDeviation="2"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter1_d_2_2" x="105" y="102" width="79" height="79" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter2_d_2_2" x="170" y="117" width="98" height="49" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter3_d_2_2" x="120" y="167" width="49" height="98" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter4_d_2_2" x="21" y="117" width="98" height="49" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter5_d_2_2" x="120" y="18" width="49" height="98" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter6_d_2_2" x="157" y="154.586" width="79.6041" height="79.0183" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter7_d_2_2" x="161.96" y="50.2487" width="79.0183" height="79.6041" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter8_d_2_2" x="49.2487" y="48.2487" width="79.6041" height="79.0183" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    <filter id="filter9_d_2_2" x="49.2487" y="154.374" width="79.0183" height="79.6041" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
    <feOffset dx="4" dy="4"/>
    <feGaussianBlur stdDeviation="3.5"/>
    <feComposite in2="hardAlpha" operator="out"/>
    <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.5 0"/>
    <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2_2"/>
    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2_2" result="shape"/>
    </filter>
    </defs>
    </svg>
    